﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using CodeMonkey.Utils;

public class MainMenuWindow : MonoBehaviour
{
    private enum Sub
    {
        Main,
        Authors,
    }
    private void Awake()
    {
        transform.Find("authorsSub").GetComponent<RectTransform>().anchoredPosition = Vector2.zero;
        transform.Find("mainSub").GetComponent<RectTransform>().anchoredPosition = Vector2.zero;

        transform.Find("mainSub").Find("playBtn").GetComponent<Button_UI>().ClickFunc = () => Loader.Load(Loader.Scene.GameScene);
        transform.Find("mainSub").Find("playBtn").GetComponent<Button_UI>().AddButtonSounds();

        transform.Find("mainSub").Find("quitBtn").GetComponent<Button_UI>().ClickFunc = () => Application.Quit();
        transform.Find("mainSub").Find("quitBtn").GetComponent<Button_UI>().AddButtonSounds();

        transform.Find("mainSub").Find("authorsBtn").GetComponent<Button_UI>().ClickFunc = () => ShowSub(Sub.Authors);
        transform.Find("mainSub").Find("authorsBtn").GetComponent<Button_UI>().AddButtonSounds();

        transform.Find("authorsSub").Find("backBtn").GetComponent<Button_UI>().ClickFunc = () => ShowSub(Sub.Main);
        transform.Find("authorsSub").Find("backBtn").GetComponent<Button_UI>().AddButtonSounds();

        ShowSub(Sub.Main);
    }

    private void ShowSub(Sub sub)
    {
        transform.Find("mainSub").gameObject.SetActive(false);
        transform.Find("authorsSub").gameObject.SetActive(false);

        switch(sub)
        {
            case Sub.Main:
                transform.Find("mainSub").gameObject.SetActive(true);
                break;
            case Sub.Authors:
                transform.Find("authorsSub").gameObject.SetActive(true);
                break;
        }
    }
}
